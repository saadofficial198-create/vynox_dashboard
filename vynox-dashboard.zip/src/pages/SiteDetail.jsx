// src/pages/SiteDetail.jsx
import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Globe, Shield, Clock, Activity } from 'lucide-react';
import toast from 'react-hot-toast';
import { api } from '../api/client';
import AlertBadge from '../components/AlertBadge';
import SiteStatusDot from '../components/SiteStatusDot';
import PageLoader from '../components/PageLoader';

function timeAgo(date) {
  if (!date) return 'Never';
  const s = Math.floor((Date.now() - new Date(date)) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s/60)}m ago`;
  if (s < 86400) return `${Math.floor(s/3600)}h ago`;
  return new Date(date).toLocaleDateString();
}

const TABS = ['Alerts', 'Scan Logs', 'Checksums'];

export default function SiteDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [site,     setSite]     = useState(null);
  const [alerts,   setAlerts]   = useState([]);
  const [scans,    setScans]    = useState([]);
  const [checksums,setChecksums]= useState([]);
  const [tab,      setTab]      = useState('Alerts');
  const [loading,  setLoading]  = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      // Load core site data first to prevent "Site not found" if other requests fail
      const sRes = await api.getSite(id);
      setSite(sRes.data);
      setLoading(false); // Render UI quickly

      // Then load secondary data independently
      api.getSiteAlerts(id, { limit: 50 })
        .then(res => setAlerts(res.data.alerts || []))
        .catch(() => {});

      api.getScanLogs(id, { limit: 20 })
        .then(res => setScans(res.data.scanLogs || []))
        .catch(() => {});

      api.getSiteChecksums(id, { limit: 100 })
        .then(res => setChecksums(res.data.checksums || []))
        .catch(() => {});

    } catch (err) {
      toast.error('Site not found');
      navigate('/sites');
      setLoading(false);
    }
  }, [id, navigate]);

  useEffect(() => { load(); }, [load]);

  const resolveAlert = async (alertId) => {
    try { await api.resolveAlert(alertId); load(); toast.success('Alert resolved'); }
    catch { toast.error('Failed'); }
  };

  if (loading) return <PageLoader />;
  if (!site) return null;

  const score = site.securityScore ?? 100;
  const scoreColor = score >= 80 ? 'var(--accent)' : score >= 50 ? 'var(--warning)' : 'var(--danger)';

  return (
    <div className="page-enter" style={{ padding: 24, overflowY: 'auto', flex: 1 }}>

      {/* Back + Header */}
      <button className="btn btn-ghost btn-sm" style={{ marginBottom: 16 }} onClick={() => navigate('/sites')}>
        <ArrowLeft size={13} /> Back to Sites
      </button>

      {/* Site card */}
      <div className="card" style={{ padding: '20px 24px', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 20, flexWrap: 'wrap' }}>
        <div style={{
          width: 52, height: 52, borderRadius: 12,
          background: 'var(--accent-dim)', border: '1px solid var(--accent)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Globe size={24} style={{ color: 'var(--accent)' }} />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
            <h2 style={{ fontSize: 20, fontWeight: 800 }}>{site.domain}</h2>
            <SiteStatusDot status={site.status} showLabel />
          </div>
          <div style={{ color: 'var(--text-secondary)', fontSize: 13, marginTop: 3, display: 'flex', gap: 16 }}>
            {site.name && site.name !== site.domain && <span>{site.name}</span>}
            {site.wpVersion && <span>WP {site.wpVersion}</span>}
            {site.phpVersion && <span>PHP {site.phpVersion}</span>}
          </div>
        </div>
        {/* Score */}
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 36, fontWeight: 900, color: scoreColor, lineHeight: 1 }}>{score}</div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>Security Score</div>
        </div>
        {/* Stats */}
        <div style={{ display: 'flex', gap: 20 }}>
          {[
            { icon: Shield, label: 'Alerts', val: alerts.length, color: 'var(--danger)' },
            { icon: Activity, label: 'Scans',  val: scans.length,  color: 'var(--info)' },
            { icon: Clock,  label: 'Last Scan', val: timeAgo(site.lastScan), color: 'var(--accent)' },
          ].map(({ icon: Icon, label, val, color }) => (
            <div key={label} style={{ textAlign: 'center' }}>
              <Icon size={14} style={{ color }} />
              <div style={{ fontWeight: 700, fontSize: 15, color }}>{val}</div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 16, borderBottom: '1px solid var(--border)', paddingBottom: 0 }}>
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)}
            style={{
              padding: '8px 18px', background: 'none', border: 'none', cursor: 'pointer',
              fontWeight: 600, fontSize: 13,
              color: tab === t ? 'var(--accent)' : 'var(--text-secondary)',
              borderBottom: tab === t ? '2px solid var(--accent)' : '2px solid transparent',
              marginBottom: '-1px', transition: 'all 0.15s',
            }}>{t}</button>
        ))}
      </div>

      {/* Tab Content */}
      {tab === 'Alerts' && (
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          {alerts.length === 0
            ? <div style={{ padding: 32, textAlign: 'center', color: 'var(--text-muted)' }}>No alerts for this site ✅</div>
            : <table className="vynox-table">
                <thead><tr><th>Severity</th><th>Type</th><th>Message</th><th>Time</th><th>Status</th><th></th></tr></thead>
                <tbody>
                  {alerts.map(a => (
                    <tr key={a._id}>
                      <td><AlertBadge severity={a.severity} /></td>
                      <td style={{ fontFamily: 'monospace', fontSize: 12, color: 'var(--text-secondary)' }}>{a.type}</td>
                      <td style={{ maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.message}</td>
                      <td style={{ color: 'var(--text-muted)', fontSize: 12, whiteSpace: 'nowrap' }}>{timeAgo(a.createdAt)}</td>
                      <td>
                        {a.resolved
                          ? <span className="badge badge-success">Resolved</span>
                          : <span className="badge badge-critical">Open</span>}
                      </td>
                      <td>
                        {!a.resolved && (
                          <button className="btn btn-ghost btn-sm" onClick={() => resolveAlert(a._id)}>Resolve</button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
          }
        </div>
      )}

      {tab === 'Scan Logs' && (
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          {scans.length === 0
            ? <div style={{ padding: 32, textAlign: 'center', color: 'var(--text-muted)' }}>No scan logs yet.</div>
            : <table className="vynox-table">
                <thead><tr><th>Type</th><th>Status</th><th>Issues</th><th>Duration</th><th>Triggered By</th><th>Time</th></tr></thead>
                <tbody>
                  {scans.map(s => (
                    <tr key={s._id}>
                      <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{s.scanType}</td>
                      <td>
                        <span className={`badge ${s.status === 'clean' ? 'badge-success' : s.status === 'issues_found' ? 'badge-critical' : 'badge-muted'}`}>
                          {s.status}
                        </span>
                      </td>
                      <td style={{ color: s.issuesFound > 0 ? 'var(--danger)' : 'var(--accent)', fontWeight: 700 }}>{s.issuesFound}</td>
                      <td style={{ color: 'var(--text-secondary)', fontSize: 12 }}>{s.durationMs ? `${s.durationMs}ms` : '—'}</td>
                      <td style={{ color: 'var(--text-muted)', fontSize: 12 }}>{s.triggeredBy}</td>
                      <td style={{ color: 'var(--text-muted)', fontSize: 12 }}>{timeAgo(s.createdAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
          }
        </div>
      )}

      {tab === 'Checksums' && (
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          {checksums.length === 0
            ? <div style={{ padding: 32, textAlign: 'center', color: 'var(--text-muted)' }}>No file checksums stored yet.</div>
            : <table className="vynox-table">
                <thead><tr><th>File Path</th><th>MD5 Hash</th><th>Status</th><th>Last Checked</th></tr></thead>
                <tbody>
                  {checksums.map(c => (
                    <tr key={c._id}>
                      <td style={{ fontFamily: 'monospace', fontSize: 11, maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.filePath}</td>
                      <td style={{ fontFamily: 'monospace', fontSize: 11, color: 'var(--text-muted)' }}>{c.md5Hash?.slice(0, 16)}...</td>
                      <td>
                        <span className={`badge ${c.status === 'clean' ? 'badge-success' : c.status === 'modified' ? 'badge-critical' : 'badge-warning'}`}>
                          {c.status}
                        </span>
                      </td>
                      <td style={{ color: 'var(--text-muted)', fontSize: 12 }}>{timeAgo(c.lastChecked)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
          }
        </div>
      )}
    </div>
  );
}
